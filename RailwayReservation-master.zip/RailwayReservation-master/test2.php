<?php
	session_start();
	$_SESSION["Ticket"] = $_REQUEST["Price"];
?>