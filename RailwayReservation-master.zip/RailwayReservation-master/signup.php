<!DOCTYPE html>
<html>
<head>
<title> Signup Form</title>
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
<div>
<h2> Sign Up Here</h2>
<form action="insert.php" method="post">
<input type="text" name="name" placeholder="Name.."><br><br>
<input type="text"  name="usern" placeholder="Username.."><br><br>
<input type="text" name='email' placeholder="Email.."><br><br>
<input type="password" name="pass" placeholder="Password.."> <br><br>
<input type="text" name="phone"placeholder="Mobile Number.."><br><br>
<input type="text" name="aadhar" placeholder="Aadhar Card Number..">
<br><br>
<input type="submit" class="btn"></button>
</form>
</div>
</body>
</html>

